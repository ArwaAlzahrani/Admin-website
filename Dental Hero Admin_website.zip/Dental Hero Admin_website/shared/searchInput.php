<div class="row justify-content-end">
    <div class="col-4 pt-2">
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">
                    <span class="fa fa-search"></span>
                </div>
            </div>
            <input type="text" class="form-control" placeholder="Search" id="searchInput"
                   onkeyup="filterTable()">
        </div>
    </div>
</div>
