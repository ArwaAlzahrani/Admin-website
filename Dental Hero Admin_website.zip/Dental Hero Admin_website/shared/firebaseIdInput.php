<!-- add hidden firebase id field for use when saving data-->
<input type="text" name="FirebaseId" hidden id="FirebaseId"
       class="form-control col-8">
